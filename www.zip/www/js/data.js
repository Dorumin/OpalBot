window.data = {};

window.data.en = {};

window.data.en.commands = {};

window.data.en.commands.utility = [
    {
        name: 'avatar',
        desc: 'Fetches the avatar of an user',
        aliases: ['avi', 'a'],
        usage: 'opal!avatar [@user]',
        description: 'Fetches the avatar of the user mentioned, or the user who executed the command.'
    },
    {
        name: 'hello',
        desc: 'Says hello to an user',
        aliases: ['hey', 'hi'],
        usage: 'opal!hello [@user]',
        description: 'Greets the user who executed the command or the user mentioned.'
    },
    {
        name: 'ping',
        desc: 'Posts ping between the bot and discord',
        aliases: ['pong'],
        usage: 'opal!ping',
        description: 'Calculates latency between Discord servers and the bot client.'
    },
    {
        name: 'prefix',
        desc: 'Allows to manipulate guild prefixes',
        aliases: ['prefixes'],
        usage: 'opal!prefix <list|add|remove> [prefix]',
        description: 'Adds or removes the selected prefix.\n\nLists guild prefixes by default.'
    },
    {
        name: 'runtime',
        desc: 'Shows bot uptime',
        aliases: ['uptime'],
        usage: 'opal!runtime',
        description: 'Shows how long the bot client has been running.'
    },
];